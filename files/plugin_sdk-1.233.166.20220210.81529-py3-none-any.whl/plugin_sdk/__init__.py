import plugin_sdk.sdk_version
__version__ = plugin_sdk.sdk_version.get_version()
