import time

#advanced function to check if time interval passed
# start_time start time in seconds
# interval time interval in seconds
# last last time of execution in second
# current current time in seconds
# return true if interval were passed otherwise false
def is_interval_passed(start_time, interval, last, current):
    if last is None: 
        return True
    lastIntervals = int(round (last-start_time)/round(interval))
    currentIntervals = int(round (current-start_time)/round(interval))
    return currentIntervals != lastIntervals

class ExecuteEveryMinute:
    def __init__(self):
        self._interval_seconds = 60
        self._start_time = time.monotonic()
        self._ts = self._start_time

    def do(self, _callable, *args, **kwargs):
        now = time.monotonic()
        if is_interval_passed(0, self._interval_seconds, self._ts, now):
            self._ts = now
            _callable(*args, **kwargs)