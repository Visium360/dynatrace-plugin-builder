class Murmur3:
    __instance = None

    def __new__(cls):
        if not cls.__instance:
            cls.__instance = object.__new__(cls)
            cls.__instance._initialized = False
        return cls.__instance

    @staticmethod
    def initialize(external_api, is_local):
        Murmur3()._init(external_api, is_local)

    def _init(self, external_api, is_local):
        if self._initialized:
            return
        self.__murmur3 = external_api.murmur_hash_3_64
        if not is_local:
            self.__get_group_id = external_api.getCustomDeviceGroupMELongId
            self.__get_device_id = external_api.getCustomDeviceMELongId
        self._initialized = True

    def murmur3(self, data: bytes) -> int:
        return self.__murmur3(data)

    def get_group_id(self, namespace : str, identifier: str) -> int:
        #namespace is not used so far, added for compatibility with IOT API
        return self.__get_group_id(namespace, identifier)

    def get_device_id(self, calculated_group_id: int, identifier: str) -> int:
        return self.__get_device_id(calculated_group_id, identifier)
