import re
from ruxit.api.snapshot import get_technologies


#PGI type check
def check_snapshot_types(entry, pg_types):
    return len(pg_types) == 0 or entry.process_type in pg_types


#PGI technology check
def check_snapshot_technologies(entry, pg_technologies):
    if len(pg_technologies) == 0:
        return True
    detected_technologies = get_technologies(entry)
    if len(detected_technologies) == 1 and len(detected_technologies[0]) == 0:
        return False
    for technology in pg_technologies:
        if technology in detected_technologies:
            return True
    return False
    

#PG name check
def check_snapshot_name(entry, name_pattern):
    return len(name_pattern) == 0 or re.search(name_pattern, entry.group_name)


# the default snapshot check function to check type and technology of PGI
def check_snapshot_entry(entry, pg_types, pg_technologies, name_pattern):
    return check_snapshot_types(entry, pg_types) and check_snapshot_technologies(entry, pg_technologies)\
           and check_snapshot_name(entry, name_pattern)
