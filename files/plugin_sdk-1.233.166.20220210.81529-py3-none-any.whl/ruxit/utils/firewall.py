import inspect
import logging
from pathlib import Path
from functools import wraps
import os.path
logger = logging.getLogger(__name__)

class BlockedException(Exception):
    """
    Should be raised code is not allowed to use specific functionality
    """
    pass


#decorator for checking Firewall API
def InternalAPI(func):
    @wraps(func)
    def InternalAPI_wrapper(*args, **kwargs):
        if Firewall.is_allowed_range_call(func.__name__, 2, 5):
            return func(*args, **kwargs)
    return InternalAPI_wrapper          

#decorator class for checking Firewall API with parameters
class InternalAPI_ext(object):
    def __init__(self, depth: int=2, exc_message: str=None):
        self.depth=depth
        self.exc_message=exc_message
        
    def __call__(self, fn, *args, **kwargs):
        def InternalAPI_wrapper(*args, **kwargs):
            if Firewall.is_allowed_range_call(fn.__name__, self.depth, 5):
                return fn(*args, **kwargs)
            elif not self.exc_message is None:
                raise BlockedException(self.exc_message)
            return fn(*args, **kwargs)
        return InternalAPI_wrapper    

class Firewall:
    
    __instance = None

    def __new__(cls):
        if not cls.__instance:
            cls.__instance = object.__new__(cls)
            cls.__instance._initialized = False
        return cls.__instance        
        
    @staticmethod
    def initialize(external_api):
        Firewall()._init_firewall(external_api)

    @staticmethod
    def is_allowed_range_call(function_name: str, depth: int, size: int):
        return Firewall()._is_allowed_range(function_name, depth + 1, size)

    @staticmethod    
    def is_allowed_call(depth: int=2):
        return Firewall()._is_allowed(depth + 1)

    @staticmethod
    def is_custom_plugin_dir(dir):
        return Firewall()._is_custom_plugin_dir(dir)

    def _init_firewall(self, external_api):
        if self._initialized:
            return        
        self.__external_api = external_api
        dirs = set()
        #get installation directory
        my_path = inspect.stack()[0][1]
        parents_dir = Path(my_path).parents
        install_dir = parents_dir[min(5, len(parents_dir) - 1)].as_posix()
        storage_dir = self.__external_api.get_storage_path()
        
        dirs.add(install_dir + "/agent/plugin/plugins/")
        dirs.add(install_dir + "/agent/conf/runtime/pluginsupdate/")
        dirs.add(install_dir + "/agent/plugin/engine/")
        dirs.add(storage_dir + "/agent/conf/runtime/plugins_unpacked/")
        dirs.add(storage_dir + "/agent/conf/runtime/engine_unpacked/")
        dirs.add(storage_dir + "/agent/runtime/plugins_unpacked/")
        dirs.add(storage_dir + "/agent/runtime/engine_unpacked/")
        self.__allowed_dirs = frozenset(dirs)
        self._initialized = True;
        logger.info("API Firewall: build-in directories: %s", self.__allowed_dirs)

    def _is_allowed_range(self, function_name, start_depth, size):
        the_stack = inspect.stack()
        for i in range(start_depth, start_depth+size):
            if i >= len(the_stack):
                return True
            plugin_path = the_stack[i][1]
            if not self._is_custom_plugin_dir(plugin_path):
                continue
            if self.__external_api.get_bool_debug_flag("debugPluginAgentFirewallLogNative", False):
                logger.info("API Firewall: call to %s is blocked for %s", function_name, plugin_path)

            return False
        return True

    def _is_allowed(self, depth):
        the_stack = inspect.stack()
        plugin_path = the_stack[depth][1]
        if not self._is_custom_plugin_dir(plugin_path):
            return True
        if self.__external_api.get_bool_debug_flag("debugPluginAgentFirewallLogNative", False):
            frame = the_stack[depth - 1]
            logger.info("API Firewall: call to %s from %s is blocked for %s", frame.funtion, frame[1], plugin_path)
        return False

    def _is_custom_plugin_dir(self, plugin_path):
        if not self._initialized:
            return False
        if not self.__external_api.get_bool_debug_flag("debugPluginAgentEnableFirewallNative", True):
            return False

        for allowed_path in self.__allowed_dirs:
            if (plugin_path.replace('\\','/')).startswith(allowed_path):
                return False
            #fixing problem with comparing paths on Windows, to avoid interpreting all added plugins as custom plugins.
        return True
