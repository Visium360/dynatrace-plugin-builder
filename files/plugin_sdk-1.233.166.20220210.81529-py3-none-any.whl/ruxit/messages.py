DOES_NOT_EXIST = "Extension doesn't exist on given host"
EXECUTION_TIMEOUT = "Extension execution timeout"
DUPLICATE = "%s has same package name like %s. User cannot define 2 or more extensions with same package name."
