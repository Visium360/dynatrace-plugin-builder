import logging
from collections import namedtuple
from .api import selectors
from .utils.select_helper import check_snapshot_entry, check_snapshot_technologies
from .api.snapshot import get_technologies, get_pids, get_ports

SingletonActivationData = namedtuple("SingletonActivationsData", ["meid", "process_types","technologies", "name_pattern"])

class PluginEngine:
    def __init__(self, activation_context, plugin_info):
        self.plugin_info = plugin_info
        self.activation_context = activation_context

    def __eq__(self, other):
        (activation_context, plugin_info) = other
        return self.plugin_info == plugin_info and \
               self.activation_context.entity_id == activation_context.entity_id and \
               self.activation_context.meid == activation_context.meid and \
               self._equal_techs(self.activation_context.value, activation_context.value) and \
               self._equal_ports(self.activation_context.value, activation_context.value) and \
               self._equal_all_pids(self.activation_context.value, activation_context.value)

    def _equal_techs(self, ac1, ac2):
        ac1_techs = set(get_technologies(ac1))
        ac2_techs = set(get_technologies(ac2))
        return ac1_techs == ac2_techs

    def _equal_ports(self, ac1, ac2):
        ac1_ports = get_ports(ac1)
        ac2_ports = get_ports(ac2)
        return ac1_ports == ac2_ports

    def _equal_all_pids(self, ac1, ac2):
        ac1_pids = get_pids(ac1)
        ac2_pids = get_pids(ac2)
        if len(ac1_pids) == 0 and len(ac2_pids) ==0:
            return True
        if len(ac1_pids.intersection(ac2_pids)) == 0:
            return False
        else:
            return True


class BaseActivationContext(namedtuple("BaseActivationContext", ["entity_id", "meid", "value"])):
    __slots__= ()                            
    """
    Base class for activation context used to remove code duplication.
    As of now, activation contexts are not required to derive from this, as long as they implement status_entity_id,
    select_id method, __eq__ semantics
    """
    def select_id(self, **kwargs):
        return self.meid

    def __eq__(self, other):
        if isinstance(other, type(self)):
            return self.value == other.value
        return NotImplemented

    def __repr__(self):
        return "{0}(entity_id=0x{1:x}, meid={2}, value={3})"\
            .format(type(self).__name__, self.entity_id, self.meid, self.value)


class SnapshotEntryActivationContext(BaseActivationContext):
    __slots__= ()
    def __new__(cls, snapshot_entry):
        return BaseActivationContext.__new__(cls,
                                             entity_id = snapshot_entry.group_instance_id,
                                             meid = (selectors.EntityType.PROCESS_GROUP_INSTANCE, snapshot_entry.group_instance_id),
                                             value = snapshot_entry)

class HostActivationContext(BaseActivationContext):
    __slots__= ()
    def __new__(cls, host_id):
        me_host_id = (selectors.EntityType.HOST, host_id)
        return BaseActivationContext.__new__(cls,
                                             entity_id = host_id,
                                             meid = me_host_id,
                                             value = me_host_id)

    @classmethod
    def select(cls, associated_technologies, snapshot):
        for snapshot_entry in snapshot.entries:
            if check_snapshot_technologies(snapshot_entry, associated_technologies):
                return cls(snapshot.host_id)
        return None


class ProcessTypeSingletonActivationContext(BaseActivationContext):
    __slots__= ()
    def __new__(cls, host_id, process_types, technologies=[], name_pattern=''):
        me_host_id = (selectors.EntityType.HOST, host_id)
        return BaseActivationContext.__new__(cls,
                                             entity_id = host_id,
                                             meid = me_host_id,
                                             value = SingletonActivationData(me_host_id, process_types, technologies, name_pattern))

    @classmethod
    def select(cls, process_types, technologies, name_pattern, snapshot):
        wanted_process_types = set (process_types)
        for snapshot_entry in snapshot.entries:
            if check_snapshot_entry(snapshot_entry, wanted_process_types, technologies, name_pattern):
                return [cls(snapshot.host_id, wanted_process_types, technologies, name_pattern)]
        return []

    @classmethod
    def get_snapshot(cls, process_types, technologies, name_pattern, process_snapshot):
        wanted_process_types = set(process_types)
        snapshot = []
        for snapshot_entry in process_snapshot.entries:
            if check_snapshot_entry(snapshot_entry, wanted_process_types, technologies, name_pattern):
                snapshot.append(snapshot_entry)
        return snapshot

class PluginSelector:
    def __init__(self):
        self.to_activate = []

    @staticmethod
    def _is_singleton(activation):
        return activation == 'Singleton' or activation == 'PgiNameSingleton'

    def select_plugins(self, snapshot, plugin_infos, active_plugin_engines, logger=logging.getLogger(__name__)):
        self.to_activate = []
        for plugin_info in plugin_infos:
            one_meta = plugin_info.json_data
            try:
                assoc_process_types = plugin_info.associated_process_types
                assoc_technologies = plugin_info.associated_technologies
                name_pattern = plugin_info.name_pattern
                if one_meta.get('entity', 'PROCESS_GROUP_INSTANCE') == "HOST":
                    host_activation_context = HostActivationContext.select(assoc_technologies, snapshot)
                    if host_activation_context:
                        self._select_for_activation(plugin_info, host_activation_context)
                    continue
                activation = one_meta.get('source', {}).get('activation', 'SnapshotEntry')
                if self._is_singleton(activation):
                    for selected_ac in ProcessTypeSingletonActivationContext.select(assoc_process_types,
                                                                                    assoc_technologies,
                                                                                    name_pattern,
                                                                                    snapshot):
                        self._select_for_activation(plugin_info, selected_ac)
                    continue
                if len(assoc_process_types) == 0 and len(assoc_technologies) == 0 and len(name_pattern) == 0:
                    continue
                for snapshot_entry in snapshot.entries:
                    if check_snapshot_entry(snapshot_entry, assoc_process_types, assoc_technologies, name_pattern):
                        self._select_for_activation(plugin_info, SnapshotEntryActivationContext(snapshot_entry))
            except Exception:
                logger.exception("Exception on selecting plugins for metadata: %s", one_meta)

        to_deactivate = []
        for plugin_engine in active_plugin_engines:
            active_info = PluginEngine(plugin_engine.activation_context, plugin_engine.plugin_info)
            if active_info not in self.to_activate:
                # this information could be extracted faster if we'd organize process_snapshot or
                # metadata informatino in sets/dictionaries - but that would have to happen
                # every time - and deactivations (for those reasons) are fairly rare
                to_deactivate.append(plugin_engine)
            else:
                self.to_activate.remove(active_info)

        return self.to_activate, to_deactivate

    def _select_for_activation(self, plugin_info, activation_context):
        self.to_activate.append((activation_context, plugin_info))
