from collections import defaultdict
from typing import Any, Mapping, Callable


class LimitChecker:
    """
        utility class to wrap limit checks functionality
    """
    def __init__(self, limit:Callable[[],int], counter:int = 0):
        """
        initialization
        :param limit: limit getter (so it can be changed in runtime)
        :param counter: initial value for counter
        """
        self._limit = limit
        self._counter = counter

    def increment(self):
        self._counter += 1

    @property
    def counter(self)->int:
        return self._counter

    @property
    def limit(self)->int:
        return self._limit()

    @property
    def limit_reached(self)->bool:
        """
        :return: true if counter is greater or equal than limit
        """
        return self.counter >= self.limit

    def reset(self):
        self._counter = 0


class MultiLimitChecker:
    """
        utility class to wrap limit checks functionality
        for several entities
    """
    def __init__(self, limit:Callable[[],int]):
        """
        initialization
        :param limit: limit getter (so it can be changed in runtime)
        """
        self._limit = limit
        self._limit_reached = False
        self._counters = defaultdict(int)
        self._limit_entity_ids = {}

    def increment(self, entity_id:str, any_data:Any=None):
        self._counters [entity_id] += 1

    def limit_detected(self, entity_id:str, any_data:Any=None)->bool:
        """
        :return: True if specific entity have reached the limit
        """
        if self._counters[entity_id] >= self.limit:
            self._limit_reached = True
            self._limit_entity_ids[entity_id] = any_data
            return True
        else:
            return False

    @property
    def limit(self):
        return self._limit()

    @property
    def limit_reached(self)->bool:
        """
        :return: true if any entities counters is greater or equal than limit
        """
        return self._limit_reached

    @property
    def limited_entities(self)->Mapping[str, Any]:
        """
        :return: map of entities ids that have reached limits
        """
        return self._limit_entity_ids

    def reset(self):
        self._limit_reached = False
        self._counters.clear()
        self._limit_entity_ids.clear()